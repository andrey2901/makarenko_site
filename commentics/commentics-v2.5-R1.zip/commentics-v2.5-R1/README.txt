Project:	Commentics

Website:	https://www.commentics.org

Version:	v2.5 (9th March 2014)

Description:	Integrates into your website to allow visitors to submit comments

Installation:	(Novice Users) Follow the 'Getting Started' guide at https://www.commentics.org/wiki/
		(Expert Users) Follow the installation and integration files in the /docs/ folder

Requirements:	See /docs/requirements.txt

Changelog:	See /docs/changelog.txt

Support:	https://www.commentics.org/forum/

Upgrade:	https://www.commentics.org/upgrade

License:	GPL v3